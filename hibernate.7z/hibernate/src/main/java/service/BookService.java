package service;

import bl.SessionUtil;
import dao.BookDAO;
import entity.Book;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class BookService extends SessionUtil implements BookDAO {

    @Override
    public void add(Book book) {
        openTransactionSession();

        Session session = getSession();
        session.save(book);

        closeTransactionSession();
    }

    @Override
    public List<Book> getAll() {
        openTransactionSession();

        Session session = getSession();

        Criteria criteria = session.createCriteria(Book.class);

        List<Book> results = criteria.list();

        closeTransactionSession();
        return results;
    }

    @Override
    public Book getByName(String name) {
        openTransactionSession();

        Session session = getSession();
        Criteria criteria = session.createCriteria(Book.class);
        criteria.add(Restrictions.eq("name",name));
        Book book = (Book) criteria.uniqueResult();

        closeTransactionSession();

        return book;
    }

    @Override
    public void update(Book book) {
        openTransactionSession();

        Session session = getSession();
        session.persist(book);//изменение состояния объекта
        session.update(book);
        closeTransactionSession();
    }

    @Override
    public void remove(Book book) {
        openTransactionSession();

        Session session = getSession();
        session.remove(book);

        closeTransactionSession();
    }
}
