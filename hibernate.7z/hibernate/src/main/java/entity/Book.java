package entity;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lab2")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;
    @Column(name = "author")
    private String author;
    @Column(name = "name")
    private String name;
    @Column(name = "type")
    private String type;
    @Column(name = "binding")
    private String binding;
    @Column(name = "price")
    private BigDecimal price;


    public Book() {
    }

    public Book(long id, String author, String name, String type, String binding, BigDecimal price) {
        this.id = id;
        this.author = author;
        this.name = name;
        this.type = type;
        this.binding = binding;
        this.price = price;
    }

    public Book(String author, String name, String type, String binding, BigDecimal price) {
        this.author = author;
        this.name = name;
        this.type = type;
        this.binding = binding;
        this.price = price;
    }

    private static List<Book> books=new ArrayList<Book>();

    public static List<Book> getBooks() {
        return books;
    }

    public static void setBooks(List<Book> books) {
        Book.books = books;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBinding() {
        return binding;
    }

    public void setBinding(String binding) {
        this.binding = binding;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String toString(){
        return "Book{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", author='" + author + '\'' +
                ", binding='" + binding + '\'' +
                ", price=" + price +
                '}';
    }
}