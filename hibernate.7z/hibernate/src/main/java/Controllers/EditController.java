package Controllers;

import entity.Book;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import service.BookService;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class EditController {
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea nameField;

    @FXML
    private TextArea authorField;

    @FXML
    private TextArea styleField;

    @FXML
    private TextArea bindingField;

    @FXML
    private TextArea priceField;

    @FXML
    private Button editButton;

    @FXML
    private TextArea choseName;

    @FXML
    private Button choseButton;

    @FXML
    void initialize() {
        //кнопка подтверждения выбора книги, заполняет поля данными выбраной книги для их редактирования
        choseButton.setOnAction(event -> {
            BookService service = new BookService();
            Book book = service.getByName(choseName.getText());

            nameField.setText(book.getName());
            authorField.setText(book.getAuthor());
            styleField.setText(book.getType());
            priceField.setText(book.getPrice().toString());
            bindingField.setText(book.getBinding());

        });
        //обновление информации о книге
        editButton.setOnAction(event -> {
            BookService service = new BookService();
            service.update(new Book(authorField.getText(),nameField.getText(),styleField.getText(),bindingField.getText(),new BigDecimal(priceField.getText())));

            //переход на стартовый экран
            editButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/Views/sample.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
}
