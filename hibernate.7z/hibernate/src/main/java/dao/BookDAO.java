package dao;

import entity.Book;

import java.util.List;

public interface BookDAO {
    //create
    void add(Book book);
    //get
    List<Book> getAll();
    Book getByName(String name);
    //update
    void update(Book book);
    //delete
    void remove(Book book);
}
