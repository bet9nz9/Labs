package sample;

import java.sql.*;

public class DBConnection {
    //данные для соединения с БД
    static final String DB_URL = "jdbc:postgresql://127.0.0.1:5432/JavaLabs";
    static final String USER = "postgres";
    static final String PASS = "msvcr100";
    Connection cn =null;

    //При создании объекта сразу открывается соединение
    public DBConnection() throws SQLException {
        try{
            cn = DriverManager.getConnection(DB_URL,USER,PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        getBooks();
    }
    //выполнение запроса на добавление новых данных
    public void addBook(Book book) throws SQLException {
        try {
            Statement st = cn.createStatement();
            st.executeUpdate("INSERT INTO lab2 (name,author,type,binding,price) values ('"+book.getName()+"','"+book.getAuthor()+"','"+book.getType()+"','"+book.getBinding()+"','"+book.getPrice()+"');");
            st.close();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        Book.getBooks().add(book);
        //cn.close();
    }
    //запрос на получение всех данных из БД
    public void getBooks() throws SQLException {
        Book.clearBooksArray();
        Statement st = cn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * from lab2;");
        while(rs.next()){
            Book.addBook(new Book(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("author"),
                    rs.getString("type"),
                    rs.getString("binding"),
                    rs.getFloat("price")
            ));
        }
        rs.close();
        st.close();
    }
    //запрос на получение опреденной строки данных
    public Book getBook(String bookName)throws SQLException{
        Book receivedBook = new Book();
        Statement st = cn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM lab2 WHERE name='" + bookName + "';");
        while(rs.next()){
                   receivedBook.setId(rs.getInt("id"));
                   receivedBook.setName(rs.getString("name"));
                   receivedBook.setAuthor(rs.getString("author"));
                   receivedBook.setType(rs.getString("type"));
                   receivedBook.setBinding(rs.getString("binding"));
                   receivedBook.setPrice(rs.getFloat("price"));
        }
        rs.close();
        st.close();
        return receivedBook;
    }
    //запрос на удаление записи
    public void deleteBook(Book book) throws SQLException {
        Statement st = cn.createStatement();
        st.executeUpdate("DELETE FROM lab2 WHERE id='"+book.getId()+"';");
        //cn.close();
    }
    //запрос на обновление записи
    public void updateBook(Book book) throws SQLException{
        Statement st = cn.createStatement();
        st.executeUpdate("UPDATE lab2 " +
                "SET name='"+book.getName()+"', author='"+book.getAuthor()+"', " +
                "type='"+book.getType()+"', binding='"+book.getBinding()+"', price='"+book.getPrice()+"'" +
                "WHERE id='"+book.getId()+";");
        st.close();
        //cn.close();
    }
}
