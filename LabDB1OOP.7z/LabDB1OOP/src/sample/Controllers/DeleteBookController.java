package sample.Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import sample.Book;
import sample.DBConnection;

public class DeleteBookController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea choseName;

    @FXML
    private Button deleteButton;

    @FXML
    void initialize() {
        //удаление книги при нажатии на кнопку
        deleteButton.setOnAction(event -> {
            try {
                DBConnection connection = new DBConnection();
                connection.deleteBook(connection.getBook(choseName.getText()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //переход на стартовый экран
            deleteButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/Views/sample.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
}
