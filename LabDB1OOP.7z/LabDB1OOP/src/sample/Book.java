package sample;

import java.sql.SQLException;
import java.util.ArrayList;

public class Book {
    static private ArrayList<Book> books = new ArrayList<>();
    private long id;
    private String name;
    private String type;
    private String author;
    private String binding;
    private float price;

    //конструкторы для различных ситуаций
    public Book(long id, String name, String type, String author, String binding, float price) throws SQLException {
        this.id = id;
        this.name = name;
        this.type = type;
        this.author = author;
        this.binding = binding;
        this.price = price;
    }
    public Book( String name, String type, String author, String binding, float price) throws SQLException {
        this.name = name;
        this.type = type;
        this.author = author;
        this.binding = binding;
        this.price = price;
    }
    public Book() {
    }
    //добавление книги в список
    public static void addBook(Book book) {
        books.add(book);
    }
    //очистка списка книг
    public static void clearBooksArray() {
        books.clear();
    }
    //получение списка
    public static ArrayList<Book> getBooks() {
        return books;
    }
    //гетеры и сетеры
    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", author='" + author + '\'' +
                ", binding='" + binding + '\'' +
                ", price=" + price +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getBinding() {
        return binding;
    }

    public void setBinding(String binding) {
        this.binding = binding;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
