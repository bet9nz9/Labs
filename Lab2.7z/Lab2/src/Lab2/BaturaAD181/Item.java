package Lab2.BaturaAD181;

public class Item {
    private float price;
    private String name;

    public Item(float price, String name){
        if(price <0)this.price=0;
        else{ this.price=price; }
        this.name=name;
    }
    //изменить цену на процент
    public void RisePrise(float percent){
        float result;
        result = ((GetPrice()*percent)+GetPrice());
        if(result<0)result=0;
        SetPrice(result);
    }
    public void ToLowerPrice(float percent){
        float result;
        result = (GetPrice()-(GetPrice()*percent));
        if(result<0)result=0;
        this.SetPrice(result);
    }
    //сетеры, гетеры
    public String GetName(){ return name; }

    public float GetPrice(){ return price; }

    public void SetName(String name){ this.name=name; }

    public void SetPrice(float price){ this.price=price; }
}
