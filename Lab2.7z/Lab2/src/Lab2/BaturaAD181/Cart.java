package Lab2.BaturaAD181;

public class Cart {
    private int arrSize;
    private Item [] arr;
    private int top=-1;

    public Cart(int arrSize){
        this.arrSize=arrSize;
        arr=new Item[this.arrSize];
    }
    //изменение цены
    public void ChangePrise(int num,float percent){
        if(num==1){
            for(int i=0;i<arrSize;i++){
                arr[i].RisePrise(percent);
            }
        }else{
            for (int i=0;i<arrSize;i++){
                arr[i].ToLowerPrice(percent);
            }
        }
    }
    //методы ддля реализации стека
    public void AddItem(Item element){
        if(!IsFool()){
        arr[++top]=element;
        }
    }
    public Item DelItem(){
        return arr[top--];
    }
    public Item ReadTop(){
        return arr[top];
    }
    public boolean IsEmpty(){
        return (top==-1);
    }
    public boolean IsFool(){
        return (top==arrSize-1);
    }
    //подсчет суммы цены всех элементов
    public float Sum(){
        float  sum=0;
        for(int i=0;i<arrSize;i++){
            sum+=arr[i].GetPrice();
        }
        return sum;
    }
    //инфо о стеке
    public void GetInfo(){
        for (int i=0;i<arrSize;i++){
            System.out.println("Element name: "+arr[i].GetName());
            System.out.println("Element price: "+arr[i].GetPrice());
        }
    }
}
