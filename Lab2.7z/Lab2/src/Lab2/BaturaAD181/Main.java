package Lab2.BaturaAD181;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int arrSize;
        System.out.println("Enter number of elements");
        Scanner scanner=new Scanner(System.in);
        arrSize=scanner.nextInt();
        Cart cart = new Cart (arrSize);
        Item newItem;
        String newName;
        float newPrice;
        float price;
        for (int i=0;i<arrSize;i++){
            System.out.println("Enter name of element.");
            newName=scanner.next();
            System.out.println("Enter price of element.");
            newPrice=scanner.nextFloat();
            newItem= new Item(newPrice,newName);
            cart.AddItem(newItem);
        }
        byte el;
        System.out.println("Sum price of item's in cart - "+cart.Sum());
        System.out.println("Enter 1 - to rise price, 2 - to lower price.");
        el=scanner.nextByte();
        System.out.println("Enter percent to change price.");
        price=scanner.nextFloat();
        cart.ChangePrise(el,price);
        cart.GetInfo();
        scanner.close();

    }
}
