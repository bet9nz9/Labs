package Lab3.BaturaAD181;

import java.util.Scanner;

public class stringTreatment {
    static public void longestBlock(){
        String string;
        System.out.println("Enter word.");
        Scanner scanner = new Scanner(System.in);
        string=scanner.next();
        char symbol=string.charAt(0);
        char finalSymbol = symbol;
        int length =1;
        int max=0;

       for(int symbolIterator=0;symbolIterator<string.length();symbolIterator++){
           if(symbol==string.charAt(symbolIterator)){
               length++;
               finalSymbol=symbol;
           }else {
               symbol=string.charAt(symbolIterator);
               length=1;
           }
           if(length>max){
               max=length;
           }
       }
        System.out.println("Longest block in word "+string);
        for(int i=0;i<max;i++){
            System.out.print(finalSymbol);
        }
        System.out.println();
        System.out.println("Length of this block " +max+" symbols.");
    }
   static public void splitWords(){
       String string;
       System.out.println("Enter string.");
       Scanner scanner = new Scanner(System.in);
       string=scanner.nextLine();
       String [] strings = string.split(" ");
       for(int wordIterator=0;wordIterator<strings.length;wordIterator++){
           System.out.println(strings[wordIterator]);
       }
   }
   static public void sumOfNumbers(){
       String string;
       System.out.println("Enter string.");
       System.out.println();
       Scanner scanner = new Scanner(System.in);
       string=scanner.nextLine();
       int sum=0;
       for(int elementIterator=0;elementIterator<string.length();elementIterator++){
           if(string.charAt(elementIterator)>='0'&&string.charAt(elementIterator)<='9'){
               sum+=Character.getNumericValue(string.charAt(elementIterator));
           }
       }
       System.out.println("Sum of numbers in string "+sum);
   }
    static public boolean isEndED(){
        String string;
        System.out.println("Enter word.");
        Scanner scanner = new Scanner(System.in);
        string=scanner.next();
       if(string.charAt(string.length()-2)=='e'&&string.charAt(string.length()-1)=='d')return true;
       else{
           return false;
       }
    }
    static public void concatenateString(){
        String string1;
        String string2;
        System.out.println("Enter first word.");
        Scanner scanner = new Scanner(System.in);
        string1=scanner.next();
        System.out.println("Enter second word.");
        string2=scanner.next();
       char arr1[];
       char arr2[];
        int iteration;
        int num=0;
        if(string1.length()<string2.length()){
            arr2=string1.toCharArray();
            arr1=string2.toCharArray();
            iteration=string2.length();
        }
        else {
            arr1=string1.toCharArray();
            arr2=string2.toCharArray();
            iteration=string1.length();
        }
        try{
            System.out.println("Result :");
            for(int i=0;i<string1.length();i++){
                num++;
                System.out.print(arr1[i]);
                System.out.print(arr2[i]);
            }
        }catch (Exception e ){
        }finally {
            for(int i=num;i<iteration;i++){
                System.out.print(arr1[i]);
            }
        }
    }
}


