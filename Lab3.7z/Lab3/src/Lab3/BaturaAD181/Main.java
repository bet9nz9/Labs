package Lab3.BaturaAD181;


public class Main {

    public static void main(String[] args) {
        System.out.println("Concatenate strings.");
        stringTreatment.concatenateString();
        System.out.println();
        System.out.println("If word end by ed.");
        System.out.println(stringTreatment.isEndED());
        System.out.println();
        System.out.println("Longest block.");
        stringTreatment.longestBlock();
        System.out.println();
        System.out.println("Split words.");
        stringTreatment.splitWords();
        System.out.println();
        System.out.println("Sum of numbers in string.");
        stringTreatment.sumOfNumbers();
    }
}
