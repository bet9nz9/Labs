package Lab8.BaturaAD181;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ButtonEventListener implements ActionListener {
    //creating components
    private ArrayList<JRadioButton> radioButtonsArray = new ArrayList<>();
    private String [] word1;
    private JTextField massage;
    private JComboBox<String> list ;
    //initialising of components
    public ButtonEventListener(ArrayList<JRadioButton> radioButtonsArray,JTextField massage,JComboBox word ) {
        this.radioButtonsArray=radioButtonsArray;
        list = word;
        this.massage = massage;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //split string to array
        word1 = massage.getText().split(" ");

        String messege = "";
        //selection one of methods processing
        if(radioButtonsArray.get(0).isSelected()){
            messege+="<Местоимение> "+word1[1]+" "+word1[2];
        }else if(radioButtonsArray.get(1).isSelected()){
            messege+=word1[0]+" бы "+word1[1]+" "+word1[2];
        }else {
            messege+=word1[0]+" "+word1[1]+" "+list.getSelectedItem();
        }
        //output of result
        JOptionPane.showMessageDialog(null,messege,"output",JOptionPane.PLAIN_MESSAGE);
    }
}
