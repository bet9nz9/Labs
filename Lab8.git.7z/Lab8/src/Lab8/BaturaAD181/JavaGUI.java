package Lab8.BaturaAD181;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class JavaGUI extends JFrame {

    //creating components
    private JButton button = new JButton("Получить результат.");
    private JLabel label = new JLabel("Введите предложение вида : <Существительное>+<глагол в прошедшем времени>+<наречие>\n");
    private JTextField massage = new JTextField("",5);
    private JLabel label2 = new JLabel("Выберите одно из действий.");
    private JRadioButton radio1 = new JRadioButton("Заменить существительное местоимением");
    private JRadioButton radio2 = new JRadioButton("Вставить после глагола «бы».");
    private JRadioButton radio3 = new JRadioButton("Заменить наречие другим, выбранным из списка.");
    private String [] words = {"word1","word2","word3"};
    private JComboBox<String> list = new JComboBox(words);
    ArrayList<JRadioButton> radioButtonsArray = new ArrayList<>();
    ButtonGroup group = new ButtonGroup();

    public JavaGUI(){
        //add components on panel
        super ("Приложение для работы с текстом.");
        Container container1 = this.getContentPane();
        container1.setLayout(new GridLayout(4,1,1,1));
        container1.add(label);
        container1.add(massage);

        group.add(radio1);
        group.add(radio2);
        group.add(radio3);
        container1.add(radio1);
        radio1.setSelected(true);
        container1.add(radio2);
        container1.add(radio3);
        container1.add(list);
        radioButtonsArray.add(radio1);
        radioButtonsArray.add(radio2);
        radioButtonsArray.add(radio3);
        //creating action listener
        button.addActionListener(new ButtonEventListener(radioButtonsArray,massage,list));
        container1.add(button);
    }

}
