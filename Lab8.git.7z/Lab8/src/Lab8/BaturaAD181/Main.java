package Lab8.BaturaAD181;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        JavaGUI gui = new JavaGUI();
        gui.pack();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setVisible(true);
    }
}
