package Lab8_2.BaturaAD181;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class JavaGui extends JFrame {
    //adding values
    private Random random =new Random();
    private Integer testNumInteger = random.nextInt(100);
    private String testNumInString = Integer.toBinaryString(testNumInteger);
    //adding elements
    private JLabel number = new JLabel(testNumInteger.toString());
    private JLabel label = new JLabel("Введите число в двоичной системе исчисления");
    private JTextField text = new JTextField("",5);
    private JButton button = new JButton("Результат");

    public JavaGui() {
        //adding elements in window
        super("Проверка перевода в двоичную систему");
        Container container = this.getContentPane();
        container.setLayout(new GridLayout(4,1));
        container.add(number);
        container.add(label);
        container.add(text);
        container.add(button);
        button.addActionListener(new ButtonEventListener());
    }
    public class ButtonEventListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            //if answer right, show dialog massage and show new number
            if(text.getText().equals(testNumInString)){
                JOptionPane.showMessageDialog(null,"Правильно.","output",JOptionPane.PLAIN_MESSAGE);
                testNumInteger = random.nextInt(100);
                testNumInString = Integer.toBinaryString(testNumInteger);
                number.setText(testNumInteger.toString());
            }else{
                    JOptionPane.showMessageDialog(null,"Неправильно.","output",JOptionPane.PLAIN_MESSAGE);
            }
        }
    }
}
