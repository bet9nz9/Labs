package Lab8_2.BaturaAD181;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        JavaGui javaGui = new JavaGui();
        javaGui.pack();
        javaGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        javaGui.setVisible(true);
    }
}
