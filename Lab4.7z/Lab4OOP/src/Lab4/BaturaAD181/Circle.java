package Lab4.BaturaAD181;

public class Circle {
    Dot center;
    int radius;

    public boolean isDotInsideCircle(Dot dot){
        return dot.getX()<(center.getX()+radius)&&dot.getX()>(center.getX()-radius)&&dot.getY()<(center.getY()+radius)&&dot.getY()>(center.getY()-radius);
    }
    public Circle(Dot center,int radius) {
        this.center = center;
        this.radius = radius;
    }
}
