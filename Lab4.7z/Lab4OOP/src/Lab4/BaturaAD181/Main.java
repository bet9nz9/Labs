package Lab4.BaturaAD181;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter x coordinate of center circle.");
        int x = scanner.nextInt();
        System.out.println("Enter y coordinate of center circle.");
        int y = scanner.nextInt();
        System.out.println("Enter radius of circle.");
        int radius = scanner.nextInt();
        Dot center=new Dot(x,y);
        Circle circle = new Circle(center,radius);
        System.out.println("Enter x coordinate of point.");
        x= scanner.nextInt();
        System.out.println("Enter y coordinate of point.");
        y=scanner.nextInt();
        Dot userDot=new Dot(x,y);
        if(circle.isDotInsideCircle(userDot)){
            System.out.println("Point in circle.");
        }else{
            System.out.println("Point out of circle.");
        }
    }
}
