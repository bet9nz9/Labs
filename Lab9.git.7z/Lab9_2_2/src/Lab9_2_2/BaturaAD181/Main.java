package Lab9_2_2.BaturaAD181;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        String text = "Old there any widow law rooms. Agreed but expect repair she nay sir silent person. Direction can dependent one bed situation attempted. His she are man their spite avoid. Her pretended fulfilled extremely education yet. Satisfied did one admitting incommode tolerably how are.\n" +
                "" +
                "Not him old music think his found enjoy merry. Listening acuteness dependent at or an. Apartments thoroughly unsatiable terminated sex how themselves. She are ten hours wrong walls stand early. Domestic perceive on an ladyship extended received do. Why jennings our whatever his learning gay perceive. Is against no he without subject. Bed connection unreserved preference partiality not unaffected. Years merit trees so think in hoped we as.\n" +
                "" +
                "Smile spoke total few great had never their too. Amongst moments do in arrived at my replied. Fat weddings servants but man believed prospect. Companions understood is as especially pianoforte connection introduced. Nay newspaper can sportsman are admitting gentleman belonging his. Is oppose no he summer lovers twenty in. Not his difficulty boisterous surrounded bed. Seems folly if in given scale. Sex contented dependent conveying advantage can use.\n" +
                "" +
                "Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor. Him had wound use found hoped. Of distrusts immediate enjoyment curiosity do. Marianne numerous saw thoughts the humoured.";
        String [] splitText = text.split(" |\\.|,|\n");
        //Задание 2.Выделить все отличающиеся слова
        Set<String> setOfStrings= new HashSet<String>();
        for(String word : splitText){
            setOfStrings.add(word);
        }
        Iterator<String> iterator = setOfStrings.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("==================================\nЗадание 3");
        //Задание 3. Выделить все различные слова и найти частоту встречаемости слова
        int totalWords = splitText.length;
        int wordFrequency =0;
        for (String word : setOfStrings){
            for (int splitTextIterator =0;splitTextIterator<splitText.length;splitTextIterator++){
                if(word.equals(splitText[splitTextIterator])){
                    wordFrequency++;
                }
            }
            System.out.println("Частота встречаемости слова "+word+" "+((double)wordFrequency/(double)totalWords));
            wordFrequency=0;
        }
    }
}
