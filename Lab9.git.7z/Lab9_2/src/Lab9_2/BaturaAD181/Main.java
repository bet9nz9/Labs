package Lab9_2.BaturaAD181;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ArrayList<Point> pointsArray = new ArrayList<Point>();
        Point point = new Point();
        System.out.println("Введите количество точек.");
        Scanner scanner = new Scanner(System.in);
        Integer number = scanner.nextInt();
        for (int iterator =0;iterator<number;iterator++){
            pointsArray.add(point.addPoint());
        }
        positionComparator comparator = new positionComparator();
        pointsArray.sort(comparator);
        for (Point p : pointsArray){
            System.out.println(p.toString());
        }
    }
}
