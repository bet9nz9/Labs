package Lab9_2.BaturaAD181;

import java.util.Comparator;

public class positionComparator implements Comparator<Point> {
    @Override
    public int compare(Point o1, Point o2) {
        if(o1.getX()==o2.getX()&&o1.getY()==o2.getY()){
            return 0;
        }else if(o1.getX()==o2.getX()&&o1.getY()>o2.getY()){
            return 1;
        }else if(o1.getX()>o2.getX()&&o1.getY()>o2.getY()){
            return 1;
        }else{
            return -1;
        }
    }
}
