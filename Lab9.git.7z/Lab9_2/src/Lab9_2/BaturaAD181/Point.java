package Lab9_2.BaturaAD181;

import java.util.Scanner;

public class Point {
    private Integer x;
    private Integer y;

    public void setX(Integer x) {
        this.x = x;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getX() {
        return x;
    }

    public Integer getY() {
        return y;
    }

    public Point(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }
    public Point (){

    }
    public Point addPoint(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите X координату ");
        setX(scanner.nextInt());
        System.out.println("Введите Y координату ");
        setY(scanner.nextInt());
        return new Point(getX(),getY());
    }
    public String toString(){
        return "Point: \nx-coordinate: "+getX()+" y-coordinate: "+getY();
    }
}
