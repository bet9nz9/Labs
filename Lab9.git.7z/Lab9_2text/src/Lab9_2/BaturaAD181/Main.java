package Lab9_2.BaturaAD181;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	    String string = "Old there any widow law rooms. Agreed but expect repair she nay sir silent person. Direction can dependent one bed situation attempted. His she are man their spite avoid. Her pretended fulfilled extremely education yet. Satisfied did one admitting incommode tolerably how are.\n" +
                " \n" +
                "Not him old music think his found enjoy merry. Listening acuteness dependent at or an. Apartments thoroughly unsatiable terminated sex how themselves. She are ten hours wrong walls stand early. Domestic perceive on an ladyship extended received do. Why jennings our whatever his learning gay perceive. Is against no he without subject. Bed connection unreserved preference partiality not unaffected. Years merit trees so think in hoped we as.\n" +
                " \n" +
                "Smile spoke total few great had never their too. Amongst moments do in arrived at my replied. Fat weddings servants but man believed prospect. Companions understood is as especially pianoforte connection introduced. Nay newspaper can sportsman are admitting gentleman belonging his. Is oppose no he summer lovers twenty in. Not his difficulty boisterous surrounded bed. Seems folly if in given scale. Sex contented dependent conveying advantage can use.\n" +
                " \n" +
                "Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor. Him had wound use found hoped. Of distrusts immediate enjoyment curiosity do. Marianne numerous saw thoughts the humoured.";
        String [] splitString = string.split("\\.");
        StringComparator stringComparator = new StringComparator();
        ArrayList<String> arrayOfStrings = new ArrayList<>();
        for(String value : splitString){
            arrayOfStrings.add(value);
        }
        arrayOfStrings.sort(stringComparator);
        for(String value : arrayOfStrings){
            System.out.println(value);
        }
    }
}
