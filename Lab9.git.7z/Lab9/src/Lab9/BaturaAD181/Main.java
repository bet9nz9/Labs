package Lab9.BaturaAD181;

import java.util.ArrayList;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Random random = new Random();
        ArrayList<Integer> arrayList = new ArrayList<>();
        for(int iterator=0;iterator<100;iterator++){
            arrayList.add(random.nextInt(2001)-1000);
        }
        for(int iterator =0;iterator<arrayList.size();iterator++){
            if(arrayList.get(iterator)<0){
                for(int iterator2=iterator;iterator2<arrayList.size();iterator2++){
                    if(arrayList.get(iterator2)>0){
                        Integer num =arrayList.get(iterator);
                        arrayList.set(iterator,arrayList.get(iterator2));
                        arrayList.set(iterator2,num);
                    }
                }
            }
        }
        for (int iterator =0;iterator<arrayList.size();iterator++){
            System.out.println(arrayList.get(iterator));
        }
    }
}
