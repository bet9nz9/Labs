package Ex.BaturaAD181;

import java.util.Date;

public class Main {

    public static void main(String[] args) throws InterruptedException {
    	DelayFiveSeconds delayFiveSeconds=new DelayFiveSeconds();
    	delayFiveSeconds.start();
		for (int i = 0; i <50 ; i++) {
			System.out.println(Thread.currentThread().getName()+" "+new Date());
			Thread.sleep(1000);
		}
    }
}
