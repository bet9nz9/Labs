package Lab5.BaturaAD181;

public class Lecturer extends Person {
    String department;
    double salary;

    public Lecturer(String surname, String name, int age, String department, double salary) {
        super(surname, name, age);
        this.department = department;
        this.salary = salary;
    }

    @Override
    public void printInfo() {
        System.out.println("Преподаватель кафедры "+department+" "+surname+" "+name+
                ", возраст: "+age+". Зарплата: "+salary);
    }
}
