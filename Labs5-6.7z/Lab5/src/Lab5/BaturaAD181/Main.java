package Lab5.BaturaAD181;

public class Main {

    public static void main(String[] args) {
	    Person person = new Person("qwert", "asdf", 20);
	    Person student = new Student("poiu", "mnbv",20,"AD-181",1569563);
	    Person lecturer = new Lecturer("cvbn","zxcvb",40,"rtyhbvgy",8000);

	    Person [] arr = {person,student,lecturer};
        for (Person iterator:arr) {
            iterator.printInfo();
        }
    }
}
