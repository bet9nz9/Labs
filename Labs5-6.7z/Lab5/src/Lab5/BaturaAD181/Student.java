package Lab5.BaturaAD181;

public class Student extends Person {
    String group;
    int studentIDNumber;

    public Student(String surname, String name, int age, String group, int studentIDNumber) {
        super(surname, name, age);
        this.group = group;
        this.studentIDNumber = studentIDNumber;
    }

    @Override
    public void printInfo() {
        System.out.println("Студент группы "+group+" "+surname+" "+name+", возраст: "+age+"." +
                " Номер студенческого билета: "+studentIDNumber);
    }
}
