package Lab6.BaturaAD181;

import java.util.ArrayList;
import java.util.List;

public class PrimeFactors implements NumberInfo {
    List<Integer> inits = new ArrayList<Integer>();
    int sum =1;
    @Override
    public int counter(int number) {
        while(true){
            if((number%2)==0){
                number/=2;
                inits.add(2);
            }else if ((number%3)==0){
                number/=3;
                inits.add(3);
            }else if((number%5)==0) {
                number/=5;
                inits.add(5);
            }else if((number%7)==0){
                number/=7;
                inits.add(7);
            } else {
                inits.add(number);
                break;
            }
        }
        for (int iterator =1; iterator<inits.size();iterator++) {
            int a = inits.get(iterator);
            int b = inits.get(iterator-1);
            if (a!=b/*inits.get(iterator) != inits.get(iterator - 1)*/) {
                sum++;
            }
        }
        return sum;
    }
}
