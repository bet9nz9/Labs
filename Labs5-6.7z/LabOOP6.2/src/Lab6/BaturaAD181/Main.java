package Lab6.BaturaAD181;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number ");
        int number = scanner.nextInt();
        NumberOfSymbols num = new NumberOfSymbols();
        PrimeFactors num2 = new PrimeFactors();
        System.out.println("Amount of symbols in number "+num.counter(number));
        System.out.println("Prime factors of this number "+num2.counter(number));
    }
}
