package Lab6.BaturaAD181;

public interface NumberInfo {
    int counter(int number);
}
