package Lab6.BaturaAD181;

public class NumberOfSymbols implements NumberInfo {
    private String arr;

    @Override
    public int counter(int number) {
        arr = Integer.toString(number);
        return arr.length();
    }
}
