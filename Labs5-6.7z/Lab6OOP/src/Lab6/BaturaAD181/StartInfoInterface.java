package Lab6.BaturaAD181;

public interface StartInfoInterface {
    void printInfo();
}
