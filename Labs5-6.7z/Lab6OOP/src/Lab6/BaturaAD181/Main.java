package Lab6.BaturaAD181;

public class Main {

    public static void main(String[] args) {
	    Human person = new Person("qqwer","tyuio",18);
	    Human student = new Student("vbn","vbnm",20,"ad-181",23456789);
	    Human lecturer = new Lecturer("rtyuio","xcvbnm",40,"fvbnkiuyghn",8529);
	    Human[] arr = new Human[]{person,student,lecturer};

        for (Human value:arr) {
            value.printInfo();
        }
        System.out.println("Interface");
        StartInfoInterface person2 = new Person2("vbn","tyuikjn",18);
        StartInfoInterface student2 = new Student2("Ad-181",128568585,"fghj","tyuijh",20);
        StartInfoInterface lecturer2 = new Lecturer2("tyuijhb",9517,"cvbn","asdfg",45);
        StartInfoInterface [] arr2 = new StartInfoInterface[]{person2,student2,lecturer2};

        for (StartInfoInterface value:arr2) {
            value.printInfo();
        }
    }
}
