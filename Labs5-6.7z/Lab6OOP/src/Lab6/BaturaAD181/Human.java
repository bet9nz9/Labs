package Lab6.BaturaAD181;

public abstract class Human {
    protected String name;
    protected String surname;
    protected int age;

    public Human(String name, String surname, int age) {
        this.name = name;
        this.surname = surname;
        this.age = age;
    }

    public abstract void printInfo();
}
