package Lab6.BaturaAD181;

public class Person2 implements StartInfoInterface {
    protected String name;
    protected String surname;
    protected int age;

    public Person2(String name, String surname, int age) {
        this.name = name;
        this.surname = surname;
        this.age = age;
    }

    @Override
    public void printInfo() {
        System.out.println("Человек "+surname+" "+name+", возраст "+age);
    }
}
