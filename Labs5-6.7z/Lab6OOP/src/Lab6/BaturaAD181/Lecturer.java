package Lab6.BaturaAD181;

public class Lecturer extends Human {
    private String department;
    private double salary;

    public Lecturer(String name, String surname, int age, String department, double salary) {
        super(name, surname, age);
        this.department = department;
        this.salary = salary;
    }

    @Override
    public void printInfo() {
        System.out.println("Преподаватель кафедры "+department+" "+surname+" "+name+
                ", возраст: "+age+". Зарплата: "+salary);
    }
}
