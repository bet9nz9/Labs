package Lab6.BaturaAD181;

public class Student2 implements StartInfoInterface {
    private String group;
    private int studentIDNumber;
    private String name;
    private String surname;
    private int age;

    public Student2(String group, int studentIDNumber, String name, String surname, int age) {
        this.group = group;
        this.studentIDNumber = studentIDNumber;
        this.name = name;
        this.surname = surname;
        this.age = age;
    }

    @Override
    public void printInfo() {
        System.out.println("Студент группы "+group+" "+surname+" "+name+", возраст: "+age+"." +
                " Номер студенческого билета: "+studentIDNumber);
    }
}
