package Lab6.BaturaAD181;

public class Student extends Human {
    private String group;
    private int studentIDNumber;

    public Student(String name, String surname, int age, String group, int studentIDNumber) {
        super(name, surname, age);
        this.group = group;
        this.studentIDNumber = studentIDNumber;
    }

    @Override
    public void printInfo() {
        System.out.println("Студент группы "+group+" "+surname+" "+name+", возраст: "+age+"." +
                " Номер студенческого билета: "+studentIDNumber);
    }
}
