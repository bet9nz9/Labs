package Lab6.BaturaAD181;

public class Person extends Human {
    public Person(String name, String surname, int age) {
        super(name, surname, age);
    }

    @Override
    public void printInfo() {
        System.out.println("Человек "+surname+" "+name+", возраст "+age);
    }
}
