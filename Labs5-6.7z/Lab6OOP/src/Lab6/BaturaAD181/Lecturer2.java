package Lab6.BaturaAD181;

public class Lecturer2 implements StartInfoInterface {
    private String department;
    private double salary;
    private String name;
    private String surname;
    private int age;

    public Lecturer2(String department, double salary, String name, String surname, int age) {
        this.department = department;
        this.salary = salary;
        this.name = name;
        this.surname = surname;
        this.age = age;
    }

    @Override
    public void printInfo() {
        System.out.println("Преподаватель кафедры "+department+" "+surname+" "+name+
                ", возраст: "+age+". Зарплата: "+salary);
    }
}
