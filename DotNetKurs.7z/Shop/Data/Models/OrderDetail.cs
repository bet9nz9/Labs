﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shop.Data.Models
{
    public class OrderDetail
    {
        public int id { get; set; }
        public int orderID { set; get; }
        public int CarID { set; get; }
        public uint price { set; get; }
        public virtual Car car { set; get; }
        public virtual Order order { set; get; }
    }
}
